Note :- To run the solver on different file change the input file in 1st cell.
	The output is provided on output File.


I have used 3 method for Sat solver:

-> Brute Force:-  This method generate all the possible assignment for n variable and try on each assignment. If this return Satisfiable clause then 			  return else try on another combination. 

		  If all the 2^n combination return unsatisfiable clauses then return False and the clause is unsatisfiable.  


-> DPLL:-  The DPLL is based on recursive backsearch algorithm.
	   Base case:-  Empty conjunct is true
        		Conjunct containing an empty disjunct is false.

	   Recursive case:-

			-> Pick an arbitrary literal and set it to true.
			-> All conjuncts containing the literal drop out, and all conjuncts containing its negation have its negation removed.
			-> Recurse.
			-> If this doesn’t result in a satisfying assignment, set the same literal to false and repeat the same procedure. 


-> Knuth's SAT0W :-  file_handling of clauses.

		-> Assign a unique number, starting from 0 and counting up, to each variable as we encounter them, using a dictionary to keep track of 			   the mapping.

		-> Variables will be encoded as numbers 0 to n−1
   			where n is the number of variables.

		-> For an unnegated literal with variable encoded as number x, encode the literal as 2x

		-> and for negated one will be 2x+1.

			  Then a clause will simply be a list of numbers that are the encoded literals


		
		For keeping track the assignment we have used watchlist.
		There are 2 function related to watchlist:
		- initialize watchlist
		- update watchlist

		The solution is recursive in approach.
